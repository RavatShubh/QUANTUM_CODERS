declare const chrome: {
    runtime?: {
      lastError?: any;
      sendMessage: (extensionId: string, message: any, callback?: (response: any) => void) => void;
    };
    tabs?: {
      query: (queryInfo: chrome.tabs.QueryInfo, callback: (result: chrome.tabs.Tab[]) => void) => void;
      sendMessage: (tabId: number, message: any, callback?: (response: any) => void) => void;
    };
    storage?: {
      local: {
        get: (keys: string | string[] | object | null, callback: (items: { [key: string]: any }) => void;
      };
    };
  };