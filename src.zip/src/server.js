const express = require("express");
const mysql = require("mysql");
const bcrypt = require("bcrypt");
const cors = require("cors");
const util = require("util");

const app = express();
app.use(express.json());
app.use(cors({ origin: "*" }));  // Allows requests from any origin (adjust as needed)

// ✅ Database Connection with Improved Error Handling
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "quantum_wallet"
});

db.connect((err) => {
    if (err) {
        console.error("❌ Database connection failed:", err);
        process.exit(1); // Exit the server if DB connection fails
    } else {
        console.log("✅ Connected to MySQL Database");
    }
});

const query = util.promisify(db.query).bind(db);

// ✅ User Registration
app.post("/register", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
    }

    try {
        const existingUsers = await query("SELECT * FROM users WHERE email = ?", [email]);
        if (existingUsers.length > 0) {
            return res.status(400).json({ error: "Email already registered" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        await query("INSERT INTO users (email, password, balance) VALUES (?, ?, ?)", [email, hashedPassword, 100]);

        res.status(201).json({ message: "Registration successful!" });
    } catch (error) {
        console.error("❌ Registration failed:", error);
        res.status(500).json({ error: "Server error" });
    }
});

// ✅ User Login with Password Verification
app.post("/login", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
    }

    try {
        const users = await query("SELECT * FROM users WHERE email = ?", [email]);

        if (users.length === 0) {
            return res.status(401).json({ error: "Invalid email or password" });
        }

        const isValidPassword = await bcrypt.compare(password, users[0].password);
        if (!isValidPassword) {
            return res.status(401).json({ error: "Invalid email or password" });
        }

        res.json({ message: "Login successful!", email: users[0].email, balance: users[0].balance });
    } catch (error) {
        console.error("❌ Login error:", error);
        res.status(500).json({ error: "Server error" });
    }
});

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
