interface Window {
    chrome?: any;
  }