(function () {
    if (typeof window.ethereum !== "undefined") {
        window.postMessage({ type: "METAMASK_AVAILABLE" }, "*");
    }
})();
