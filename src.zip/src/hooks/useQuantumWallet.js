import { useState, useEffect } from 'react';

export default function useQuantumWallet() {
  const [walletAccount, setWalletAccount] = useState(null);
  const [isExtensionInstalled, setIsExtensionInstalled] = useState(false);
  const [connectionError, setConnectionError] = useState(null);

  useEffect(() => {
    const checkExtension = () => {
      const installed = typeof chrome !== 'undefined' && 
                       !!chrome.runtime &&
                       !!chrome.tabs;
      setIsExtensionInstalled(installed);
    };

    const handleMessage = (event) => {
      if (event.data?.type === 'QUANTUM_WALLET_CONNECTED') {
        setWalletAccount(event.data.account);
        setConnectionError(null);
      }
    };

    checkExtension();
    window.addEventListener('message', handleMessage);

    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const connectWallet = async () => {
    if (!isExtensionInstalled) {
      window.open('https://chrome.google.com/webstore', '_blank');
      return { error: 'Extension not installed' };
    }

    try {
      const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
      if (!tab?.id) throw new Error('No active tab found');
      
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "connectQuantumWallet"
      });
      
      return response || { success: true };
    } catch (error) {
      setConnectionError('Failed to connect to wallet');
      console.error("Connection error:", error);
      return { error: error.message };
    }
  };

  return { 
    walletAccount, 
    isExtensionInstalled, 
    connectionError,
    connectWallet 
  };
}