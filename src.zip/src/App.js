/* global chrome */
import React, { useState, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';

function App() {
  const [connectingProduct, setConnectingProduct] = useState(null);
  const [connectionError, setConnectionError] = useState(null);
  const [isExtensionInstalled, setIsExtensionInstalled] = useState(false);
  const [isChrome, setIsChrome] = useState(true);

  const EXTENSION_ID = "lionpmmlnmpnjebighdkaoallfilcngf";

  useEffect(() => {
    const isChromeBrowser = !!window.chrome && !!chrome.runtime;
    setIsChrome(isChromeBrowser);
    
    if (!isChromeBrowser) {
      setIsExtensionInstalled(false);
      return;
    }

    const checkExtension = () => {
      chrome.runtime.sendMessage(
        EXTENSION_ID,
        { action: 'ping' },
        (response) => {
          if (chrome.runtime.lastError) {
            setIsExtensionInstalled(false);
          } else {
            setIsExtensionInstalled(true);
          }
        }
      );
    };

    checkExtension();
    const interval = setInterval(checkExtension, 3000);
    return () => clearInterval(interval);
  }, []);

  const products = [
    {
      id: 1,
      name: "Premium Headphones",
      description: "Noise cancellation with immersive sound.",
      price: 349.99,
      image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=500&q=80"
    },
    {
      id: 2,
      name: "Smart Watch Pro",
      description: "Advanced health monitoring with retina display.",
      price: 429.99,
      image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=500&q=80"
    },
    {
      id: 3,
      name: "Wireless Earbuds",
      description: "True wireless earbuds with spatial audio.",
      price: 179.99,
      image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=500&q=80"
    }
  ];

  const openQuantumWallet = async () => {
    if (!isExtensionInstalled) {
      setConnectionError("Quantum Wallet extension not detected");
      return;
    }
  
    chrome.runtime.sendMessage(
      EXTENSION_ID,
      { action: "open_popup" },
      (response) => {
        if (chrome.runtime.lastError || response?.error) {
          setConnectionError(response?.error || chrome.runtime.lastError.message || "Extension not responding");
        }
      }
    );
  };

  return (
    <Container>
      <Header>Premium Products Collection</Header>
      {!isChrome && <ExtensionWarning>This feature requires Google Chrome browser.</ExtensionWarning>}
      {isChrome && !isExtensionInstalled && (
        <ExtensionWarning>
          Quantum Wallet extension not detected. Make sure:
          <ul>
            <li>The extension is installed and enabled</li>
            <li>You've refreshed this page after installation</li>
            <li>The extension ID matches: {EXTENSION_ID}</li>
          </ul>
        </ExtensionWarning>
      )}
      <ProductsContainer>
        {products.map((product) => (
          <ProductCard key={product.id}>
            <ProductImage src={product.image} alt={product.name} />
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <Price>${product.price.toFixed(2)}</Price>
            <WalletButton
              onClick={() => openQuantumWallet(product.id)}
              disabled={!isExtensionInstalled || connectingProduct !== null}
              aria-busy={connectingProduct === product.id}
            >
              {connectingProduct === product.id ? "Opening Wallet..." : "Pay with QUANTUM Wallet"}
            </WalletButton>
            {connectionError && connectingProduct === product.id && <ErrorMessage>{connectionError}</ErrorMessage>}
          </ProductCard>
        ))}
      </ProductsContainer>
    </Container>
  );
}

const Container = styled.div`font-family: "Inter", sans-serif; max-width: 1200px; margin: 0 auto; padding: 40px 20px;`;
const Header = styled.h1`text-align: center; color: #2d3748; margin-bottom: 50px; font-weight: 600; font-size: 2.5rem; background: linear-gradient(90deg, #4f46e5, #3b82f6); -webkit-background-clip: text; -webkit-text-fill-color: transparent;`;
const ProductsContainer = styled.div`display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px;`;
const ProductCard = styled.div`background: white; border-radius: 12px; padding: 25px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); transition: all 0.3s ease; &:hover { transform: translateY(-5px); }`;
const WalletButton = styled.button`background: linear-gradient(90deg, #4f46e5, #3b82f6); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; width: 100%; font-size: 1rem; font-weight: 500; transition: all 0.3s ease; &:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); } &:disabled { opacity: 0.7; }`;
const ErrorMessage = styled.div`color: #ef4444; background: #fee2e2; padding: 12px; border-radius: 8px; margin-top: 15px; border: 1px solid #fca5a5; font-size: 0.9rem;`;
const ProductImage = styled.img`width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 15px;`;
const Price = styled.p`font-weight: bold; color: #4f46e5; margin: 10px 0;`;
const ExtensionWarning = styled.div`background: #fff3cd; color: #856404; padding: 20px; border-radius: 12px; margin-bottom: 30px; border: 1px solid #ffeeba;`;

export default App;
