import React, { useState, useEffect } from "react";
import styled from "styled-components";

// Styled Components (UI)
const Container = styled.div`
  font-family: "Inter", sans-serif;
  max-width: 1200px;
  margin: auto;
  padding: 40px 20px;
`;

const Header = styled.h1`
  text-align: center;
  color: #2d3748;
  font-size: 2.5rem;
  background: linear-gradient(90deg, #4f46e5, #3b82f6);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
`;

const ProductCard = styled.div`
  background: white;
  border-radius: 12px;
  padding: 25px;
  box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
  &:hover {
    transform: translateY(-5px);
  }
`;

const WalletButton = styled.button`
  background: linear-gradient(90deg, #4f46e5, #3b82f6);
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  width: 100%;
  font-size: 1rem;
  margin-top: 15px;
  &:hover {
    transform: translateY(-2px);
  }
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
`;

const ErrorMessage = styled.p`
  color: red;
  font-size: 0.9rem;
  text-align: center;
`;

// React Component
const ProductInterface = () => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionError, setConnectionError] = useState(null);
  const [selectedAccount, setSelectedAccount] = useState(null);
  
  const extensionId = "your-extension-id-here"; // Replace with your actual extension ID

  const connectQuantumWallet = async () => {
    setIsConnecting(true);
    setConnectionError(null);

    try {
      if (window.chrome?.runtime) {
        window.chrome.runtime.sendMessage(
          extensionId,
          { action: "quantum_requestAccounts" },
          (response) => {
            if (window.chrome.runtime.lastError) {
              console.error("Extension error:", window.chrome.runtime.lastError);
              setConnectionError("Quantum Wallet extension is not responding.");
              return;
            }

            if (response?.accounts?.length > 0) {
              setSelectedAccount(response.accounts[0]);
              alert(`Connected to Quantum Wallet: ${response.accounts[0]}`);
            } else {
              setConnectionError("No accounts found in Quantum Wallet.");
            }
          }
        );
      } else {
        setConnectionError("Quantum Wallet extension is not installed.");
        window.open(
          "https://chrome.google.com/webstore/detail/quantum-wallet/your-extension-id",
          "_blank"
        );
      }
    } catch (error) {
      setConnectionError("Failed to connect to Quantum Wallet");
      console.error("Connection error:", error);
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <Container>
      <Header>Connect to Quantum Wallet</Header>

      <ProductCard>
        <p>Click the button below to connect your Quantum Wallet.</p>
        <WalletButton onClick={connectQuantumWallet} disabled={isConnecting}>
          {isConnecting ? "Connecting..." : "Connect Quantum Wallet"}
        </WalletButton>

        {selectedAccount && <p>Connected Account: {selectedAccount}</p>}
        {connectionError && <ErrorMessage>{connectionError}</ErrorMessage>}
      </ProductCard>
    </Container>
  );
};

export default ProductInterface;
