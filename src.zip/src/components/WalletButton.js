import useQuantumWallet from '../hooks/useQuantumWallet';
import './WalletButton.css'; // Create this file for styles

export default function WalletButton() {
  const { 
    walletAccount, 
    isExtensionInstalled, 
    connectionError,
    connectWallet 
  } = useQuantumWallet();

  const handleClick = async () => {
    const result = await connectWallet();
    if (result?.error) {
      console.error(result.error);
    }
  };

  return (
    <div className="wallet-connector">
      <button
        onClick={handleClick}
        disabled={!!walletAccount}
        className={`wallet-button ${walletAccount ? 'connected' : ''}`}
      >
        {walletAccount 
          ? `Connected: ${walletAccount.substring(0, 6)}...${walletAccount.substring(walletAccount.length - 4)}`
          : isExtensionInstalled 
            ? 'Connect QUANTUM Wallet' 
            : 'Install QUANTUM Wallet'
        }
      </button>
      
      {connectionError && (
        <p className="error-message">{connectionError}</p>
      )}
      
      {!isExtensionInstalled && (
        <p className="install-hint">
          You need the QUANTUM Wallet extension to continue
        </p>
      )}
    </div>
  );
}