// Handle messages from your React app
chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  const allowedOrigins = [
    /http:\/\/localhost(:\d+)?/,
    /http:\/\/127.0.0.1(:\d+)?/,
    /https:\/\/yourdomain\.com/
  ];

  if (!allowedOrigins.some(regex => regex.test(sender.url))) {
    sendResponse({ error: "Unauthorized origin" });
    return true;
  }

  if (request.action === "ping") {
    sendResponse({ success: true, version: "1.0.0" });
    return true;
  }

  if (request.action === "open_popup") {
    chrome.action.openPopup(); // Opens the real extension popup
    sendResponse({ success: true });
    return true;
  }

  sendResponse({ error: "Unknown action" });
  return true;
});
