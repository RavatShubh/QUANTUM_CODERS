// global.d.ts
interface Window {
    chrome?: {
      runtime?: {
        lastError?: any;
        sendMessage: (extensionId: string, message: any, callback?: (response: any) => void) => void;
        onMessageExternal: any;
        getURL: (path: string) => string;
      };
      tabs?: {
        query: (queryInfo: chrome.tabs.QueryInfo, callback: (result: chrome.tabs.Tab[]) => void) => void;
        sendMessage: (tabId: number, message: any, callback?: (response: any) => void) => void;
      };
      storage?: {
        local: {
          get: (keys: string | string[] | object | null, callback: (items: { [key: string]: any }) => void;
        };
      };
      windows?: {
        create: (createData: object, callback?: (window: chrome.windows.Window) => void) => void;
      };
    };
  }