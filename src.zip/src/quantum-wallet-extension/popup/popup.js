document.addEventListener("DOMContentLoaded", () => {
    // DOM Elements
    const loginContainer = document.getElementById("loginContainer");
    const walletContainer = document.getElementById("walletContainer");
    const loginButton = document.getElementById("loginButton");
    const logoutButton = document.getElementById("logoutButton");
    const userIdInput = document.getElementById("userId");
    const passwordInput = document.getElementById("password");
    const accountInfo = document.getElementById("accountInfo");
    const walletStatus = document.getElementById("statusText");
    const connectButton = document.getElementById("connectButton");
    const walletBalance = document.getElementById("walletBalance");
    const creditButton = document.getElementById("creditButton");
    const deductButton = document.getElementById("deductButton");

    let web3;
    let account;
    let wallet;

    const RPC_URL = "https://mainnet.infura.io/v3/0a0908dcad674464a1f135f1c6506b3c";
    const PRIVATE_KEY = "your-private-key-here"; // Replace with real private key
    const provider = new Web3.providers.HttpProvider(RPC_URL);
    web3 = new Web3(provider);

    // Check if Chrome Extension Storage is Available
    if (typeof chrome !== "0720...ecv" && chrome.storage) {
        checkLoginState();
    }

    // Event Listeners
    loginButton?.addEventListener("click", handleLogin);
    logoutButton?.addEventListener("click", handleLogout);
    connectButton?.addEventListener("click", connectWallet);
    creditButton?.addEventListener("click", creditAmount);
    deductButton?.addEventListener("click", deductAmount);

    function checkLoginState() {
        chrome.storage.local.get(["isLoggedIn", "userEmail"], (result) => {
            if (result.isLoggedIn) {
                showWallet(result.userEmail);
            } else {
                showLogin();
            }
        });
    }

    function showLogin() {
        loginContainer.style.display = "block";
        walletContainer.style.display = "none";
    }

    function handleLogin() {
        const email = userIdInput.value.trim();
        const password = passwordInput.value.trim();

        if (!email || !password) {
            alert("Please enter a valid email and password.");
            return;
        }

        chrome.storage.local.set({ isLoggedIn: true, userEmail: email }, () => {
            showWallet(email);
        });
    }

    function handleLogout() {
        chrome.storage.local.set({ isLoggedIn: false, userEmail: null }, () => {
            showLogin();
        });
    }
    function loadExternalScript(url) {
        return new Promise((resolve, reject) => {
            const script = document.createElement("script");
            script.src = url;
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    // Load EthereumJS-Util dynamically
    loadExternalScript("https://cdnjs.cloudflare.com/ajax/libs/ethereumjs-util/7.1.3/ethereumjs-util.umd.min.js")
        .then(() => {
            console.log("EthereumJS-Util loaded successfully!");
            // You can now use EthereumJS-Util functions
        })
        .catch((error) => {
            console.error("Failed to load EthereumJS-Util:", error);
        });


    async function connectWallet() {
        try {
            wallet = web3.eth.accounts.privateKeyToAccount(PRIVATE_KEY);
            account = wallet.address; // Public Ethereum Address

            // ✅ Extract the Public Key Using ethereumjs-util
            const provider = new Web3(window.ethereum);
            await window.ethereum.request({ method: "eth_requestAccounts" });
            const signer = provider.getSigner();


            walletStatus.innerText = `Connected: ${account}`;
            console.log("Public Key:", publicKey);

            showWallet(account, publicKey);
            fetchBalance();
        } catch (error) {
            console.error("Connection Error:", error);
            alert("Failed to connect wallet. Please check the private key.");
        }
    }

    function showWallet(account, publicKey) {
        loginContainer.style.display = "none";
        walletContainer.style.display = "block";

        // ✅ Display Wallet Address & Public Key
        accountInfo.innerHTML = `<strong>Wallet Address:</strong> ${account}<br>
                                 <strong>Public Key:</strong> ${publicKey}`;
    }

    async function fetchBalance() {
        if (!account) {
            alert("Please connect your wallet first.");
            return;
        }

        try {
            const balanceWei = await web3.eth.getBalance(account);
            const balanceEth = web3.utils.fromWei(balanceWei, "ether");
            walletBalance.textContent = `Balance: ${parseFloat(balanceEth).toFixed(4)} ETH`;
        } catch (error) {
            console.error("Failed to fetch balance:", error);
            alert("Error fetching wallet balance. Please try again.");
        }
    }

    async function creditAmount() {
        alert("Credit function requires backend API integration.");
    }

    async function deductAmount() {
        if (!account) {
            alert("Please connect your wallet first.");
            return;
        }

        const recipient = prompt("Enter recipient address:");
        const amountEth = prompt("Enter amount to send (ETH):");

        if (!recipient || !amountEth) {
            alert("Transaction canceled.");
            return;
        }

        try {
            const amountWei = web3.utils.toWei(amountEth, "ether");
            const signedTx = await web3.eth.accounts.signTransaction(
                {
                    from: account,
                    to: recipient,
                    value: amountWei,
                    gas: 21000,
                },
                PRIVATE_KEY
            );

            const sentTx = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);

            alert(`Transaction successful! Tx Hash: ${sentTx.transactionHash}`);
            fetchBalance();
        } catch (error) {
            console.error("Transaction failed:", error);
            alert("Transaction failed. Please check your wallet and try again.");
        }
    }
});
