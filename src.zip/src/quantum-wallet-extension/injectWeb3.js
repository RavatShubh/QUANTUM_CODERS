document.addEventListener("DOMContentLoaded", function () {
    const script = document.createElement("script");
    
    // Load Web3.js from local extension storage (avoiding CSP issues)
    script.src = chrome.runtime.getURL("web3.min.js");
    
    script.onload = function () {
        console.log("Web3.js injected successfully.");
        this.remove(); // Remove script tag after execution
    };

    if (document.head) {
        document.head.appendChild(script);
    } else {
        console.error("Failed to inject Web3.js: document.head is null.");
    }
});
