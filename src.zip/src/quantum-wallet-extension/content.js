chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("🔵 Content script received message:", request);

  if (request.action === "quantumWalletConnect") {
    chrome.storage.local.get(["quantumAccount"], (result) => {
      if (chrome.runtime.lastError || !result.quantumAccount) {
        sendResponse({ success: false, error: "Wallet not found." });
        return;
      }

      console.log("✅ Quantum Wallet connected:", result.quantumAccount);
      sendResponse({ success: true, account: result.quantumAccount });
    });
    return true; // Keep message channel open for async response
  }
});
